# BaseAutomation — Audit Notes

Issues identified during unit test writing for `BaseAutomation`, `BondAutomation` and `ReservesAutomation`.

---

## 🔴 Bug 1 — `setChainlinkForwarder`: "set-once" guard bypassable with `address(0)`

**File:** `src/automation/BaseAutomation.sol`  
**Function:** `setChainlinkForwarder`

### Code

```solidity
function setChainlinkForwarder(address _chainlinkForwarder)
    external onlyRole(AUTOMATION_ADMIN_ROLE)
{
    if (s_chainlinkForwarder != address(0)) {
        revert BaseAutomation__ChainlinkForwarderAddressAlreadySet();
    }
    s_chainlinkForwarder = _chainlinkForwarder;
}
```

### Problem

The guard uses `address(0)` as its sentinel value, but the storage variable `s_chainlinkForwarder` is initialised to `address(0)` by default. If an admin calls `setChainlinkForwarder(address(0))`:

1. The guard does not trigger (`address(0) != address(0)` → `false`)
2. The value stays `address(0)`
3. The function can be called again indefinitely

The invariant "can be set only once" is broken.

### Fix

Add a zero-address check on the input, consistent with the pattern already used in `BondAutomation`'s constructor:

```solidity
if (_chainlinkForwarder == address(0)) revert BaseAutomation__InvalidForwarderAddress();
```

---

## 🔴 Bug 2 — `setUpkeepId`: "set-once" guard bypassable with `0`

**File:** `src/automation/BaseAutomation.sol`  
**Function:** `setUpkeepId`

### Code

```solidity
function setUpkeepId(uint256 _upkeepId) external onlyRole(AUTOMATION_ADMIN_ROLE) {
    if (s_upkeepId != 0) {
        revert BaseAutomation__ChainlinkUpkeepIdAlreadySet();
    }
    s_upkeepId = _upkeepId;
}
```

### Problem

`0` is used as the sentinel value for "not yet set", but `0` is also a technically valid upkeep ID in the Chainlink Automation registry. Calling `setUpkeepId(0)`:

1. Does not trigger the guard (`0 != 0` → `false`)
2. Writes `0` into storage (no change)
3. Leaves the function callable again indefinitely

### Fix

Either validate the input explicitly:

```solidity
if (_upkeepId == 0) revert BaseAutomation__InvalidUpkeepId();
```

Or replace the sentinel pattern with a dedicated boolean flag:

```solidity
bool private s_upkeepIdSet;

function setUpkeepId(uint256 _upkeepId) external onlyRole(AUTOMATION_ADMIN_ROLE) {
    if (s_upkeepIdSet) revert BaseAutomation__ChainlinkUpkeepIdAlreadySet();
    s_upkeepIdSet = true;
    s_upkeepId = _upkeepId;
}
```

---

## 🟡 Issue 3 — `ManualUpkeepExecuted` emitted even when Chainlink calls after grace period

**File:** `src/automation/BaseAutomation.sol`  
**Function:** `performUpkeep`

### Code

```solidity
} else {
    // After grace period: only Chainlink Automation or admin can call
    if (
        msg.sender != address(s_chainlinkForwarder) &&
        !hasRole(AUTOMATION_ADMIN_ROLE, msg.sender)
    ) {
        revert BaseAutomation__OnlyChainlinkAutomationOrOwner();
    }

    emit ManualUpkeepExecuted(msg.sender, block.timestamp); // ← always emitted
}
```

### Problem

The event `ManualUpkeepExecuted` is emitted unconditionally in the post-grace-period branch, regardless of whether `msg.sender` is the Chainlink forwarder or a human admin. If Chainlink is simply late (arrives after the grace window), the event fires with the forwarder address as `caller`.

Any off-chain monitoring system listening for `ManualUpkeepExecuted` to detect human interventions will receive **false positives** every time Chainlink is delayed, making the event unreliable for alerting and auditing.

### Fix

Emit the event only when the caller is not the forwarder:

```solidity
} else {
    if (
        msg.sender != address(s_chainlinkForwarder) &&
        !hasRole(AUTOMATION_ADMIN_ROLE, msg.sender)
    ) {
        revert BaseAutomation__OnlyChainlinkAutomationOrOwner();
    }

    if (msg.sender != address(s_chainlinkForwarder)) {
        emit ManualUpkeepExecuted(msg.sender, block.timestamp);
    }
}
```

---

## 🟡 Issue 4 — Upkeep inaccessible during grace period if forwarder is not set

**File:** `src/automation/BaseAutomation.sol`  
**Function:** `performUpkeep`

### Code

```solidity
if (withinGracePeriod) {
    if (msg.sender != address(s_chainlinkForwarder)) {
        revert BaseAutomation__OnlyChainlinkAutomation();
    }
}
```

### Problem

If `setChainlinkForwarder` has not been called yet (or has been set to `address(0)` via Bug 1), `s_chainlinkForwarder` is `address(0)`. The check becomes:

```solidity
if (msg.sender != address(0)) revert ...;
```

Since no one can send transactions from `address(0)`, **no one can execute upkeep during the 6-hour grace period**. After the grace period expires the admin can intervene manually, so this is not a permanent freeze, but it represents a concrete operational risk during deployment: the window between the contract being deployed and `setChainlinkForwarder` being called leaves the protocol unable to process its first scheduled upkeep automatically.

### Fix

Either document and enforce that `setChainlinkForwarder` must be called atomically in the same deployment transaction, or allow the admin to execute upkeep unconditionally when `s_chainlinkForwarder == address(0)`:

```solidity
if (withinGracePeriod) {
    bool forwarderSet = s_chainlinkForwarder != address(0);
    if (forwarderSet && msg.sender != s_chainlinkForwarder) {
        revert BaseAutomation__OnlyChainlinkAutomation();
    }
    if (!forwarderSet && !hasRole(AUTOMATION_ADMIN_ROLE, msg.sender)) {
        revert BaseAutomation__OnlyChainlinkAutomation();
    }
}
```

---

## Summary

| # | Severity | Contract | Description |
|---|----------|----------|-------------|
| 1 | 🔴 Bug | `BaseAutomation` | `setChainlinkForwarder` set-once guard bypassable with `address(0)` |
| 2 | 🔴 Bug | `BaseAutomation` | `setUpkeepId` set-once guard bypassable with `0` |
| 3 | 🟡 Issue | `BaseAutomation` | `ManualUpkeepExecuted` emitted for late Chainlink calls, misleading off-chain monitoring |
| 4 | 🟡 Issue | `BaseAutomation` | Grace period fully locked if forwarder not set at deploy time |
