// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {Test} from "forge-std/Test.sol";
import {IAccessControl} from "@openzeppelin/contracts/access/IAccessControl.sol";
import {MockBondFunctionsConsumer} from "./mocks/MockBondFunctionsConsumer.sol";
import {MockReservesFunctionsConsumer} from "./mocks/MockReservesFunctionsConsumer.sol";

/**
 * @title BaseTest
 * @notice Abstract base test contract shared across all automation and oracle test files.
 *         Provides common accounts, constants, mocks and time-travel helpers.
 *         Child contracts must call super.setUp() inside their own setUp().
 *
 * NOTE on timing strategy
 * ─────────────────────────────────────────────────────────────────────────────
 * Foundry starts with block.timestamp = 1.
 * Automation tests rely on this (checkUpkeep returns false before interval).
 * Oracle tests need block.timestamp >> STALENESS_THRESHOLD so that uninitialized
 * data (timestamp = 0) is correctly seen as stale.
 * Therefore setUp() does NOT call vm.warp. Oracle test files call _warpToStart()
 * explicitly inside their own setUp() after super.setUp().
 */
abstract contract BaseTest is Test {
    // ─── Roles ────────────────────────────────────────────────────────────────
    bytes32 internal constant DEFAULT_ADMIN_ROLE    = bytes32(0);
    bytes32 internal constant AUTOMATION_ADMIN_ROLE = keccak256("AUTOMATION_ADMIN_ROLE");
    bytes32 internal constant UPDATER_ROLE          = keccak256("UPDATER_ROLE");

    // ─── Accounts (initialised in setUp via makeAddr) ─────────────────────────
    address internal ADMIN;
    address internal NON_ADMIN;
    address internal CHAINLINK_FORWARDER;

    // ─── Automation constants ─────────────────────────────────────────────────
    uint256 internal constant INTERVAL     = 1 days;
    uint256 internal constant GRACE_PERIOD = 6 hours;
    uint256 internal constant UPKEEP_ID    = 42;

    // ─── Oracle constants ─────────────────────────────────────────────────────
    /// @dev Must match the STALENESS_THRESHOLD in BondOracle and ReservesOracle.
    uint256 internal constant STALENESS_THRESHOLD = 48 hours;

    /// @dev Starting timestamp for oracle tests: far past STALENESS_THRESHOLD
    ///      so that uninitialized oracle data (timestamp = 0) is treated as stale.
    uint256 internal constant STARTING_TIMESTAMP = 200 days;

    // ─── Mocks (automation) ───────────────────────────────────────────────────
    MockBondFunctionsConsumer     internal mockBondConsumer;
    MockReservesFunctionsConsumer internal mockReservesConsumer;

    // ─── Events ───────────────────────────────────────────────────────────────
    event ManualUpkeepExecuted(address indexed caller, uint256 timestamp);

    // ─── BaseAutomation custom errors ─────────────────────────────────────────
    error BaseAutomation__ChainlinkForwarderAddressAlreadySet();
    error BaseAutomation__ChainlinkUpkeepIdAlreadySet();
    error BaseAutomation__UpkeepNotNeeded();
    error BaseAutomation__OnlyChainlinkAutomation();
    error BaseAutomation__OnlyChainlinkAutomationOrOwner();

    // ─── Setup ────────────────────────────────────────────────────────────────

    function setUp() public virtual {
        ADMIN               = makeAddr("admin");
        NON_ADMIN           = makeAddr("nonAdmin");
        CHAINLINK_FORWARDER = makeAddr("chainlinkForwarder");

        mockBondConsumer     = new MockBondFunctionsConsumer();
        mockReservesConsumer = new MockReservesFunctionsConsumer();
    }

    // ─── Automation time helpers ──────────────────────────────────────────────

    function _warpInsideGracePeriod(uint256 lastUpkeepTimestamp) internal {
        vm.warp(lastUpkeepTimestamp + INTERVAL + 1);
    }

    function _warpPastGracePeriod(uint256 lastUpkeepTimestamp) internal {
        vm.warp(lastUpkeepTimestamp + INTERVAL + GRACE_PERIOD + 1);
    }

    // ─── Oracle time helpers ──────────────────────────────────────────────────

    /// @dev Sets block.timestamp to STARTING_TIMESTAMP so that uninitialized
    ///      oracle data (timestamp = 0) is considered stale.
    ///      Must be called explicitly in oracle test setUp(), NOT here.
    function _warpToStart() internal {
        vm.warp(STARTING_TIMESTAMP);
    }

    /// @dev Warps past the staleness window from the current block.timestamp.
    function _warpPastStaleness() internal {
        vm.warp(block.timestamp + STALENESS_THRESHOLD + 1);
    }

    // ─── AccessControl helper ─────────────────────────────────────────────────

    /// @dev Encodes the OZ v5 AccessControlUnauthorizedAccount revert payload.
    function _unauthorizedRevert(address account, bytes32 role)
        internal
        pure
        returns (bytes memory)
    {
        return abi.encodeWithSelector(
            IAccessControl.AccessControlUnauthorizedAccount.selector,
            account,
            role
        );
    }
}
