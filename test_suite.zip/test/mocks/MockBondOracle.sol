// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

/**
 * @title MockBondOracle
 * @notice Minimal IBondOracle mock for BondFunctionsConsumer tests.
 *
 * Tracks how many times updateYields has been called and exposes a
 * `shouldRevert` flag to exercise the try-catch branch in _fulfillRequest.
 */
contract MockBondOracle {
    uint256 public updateCallCount;
    bool    public shouldRevert;

    function updateYields(
        uint256[] memory,
        uint256,
        bytes memory
    ) external {
        if (shouldRevert) revert("mock oracle revert");
        updateCallCount++;
    }

    function setShouldRevert(bool _shouldRevert) external {
        shouldRevert = _shouldRevert;
    }
}
