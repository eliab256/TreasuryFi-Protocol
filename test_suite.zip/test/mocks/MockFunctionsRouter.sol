// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

/**
 * @title MockFunctionsRouter
 * @notice Minimal mock for the Chainlink IFunctionsRouter.
 *
 * FunctionsClient calls i_router.sendRequest(...) inside _sendRequest.
 * This mock accepts any call and returns a deterministic request ID.
 *
 * To test _fulfillRequest in consumer contracts, tests call
 * handleOracleFulfillment directly using vm.prank(address(mockRouter))
 * because FunctionsClient gates that function to msg.sender == i_router.
 */
contract MockFunctionsRouter {
    bytes32 public constant MOCK_REQUEST_ID = keccak256("mockRequestId");

    /// @dev Matches the IFunctionsRouter.sendRequest signature invoked by
    ///      FunctionsClient._sendRequest in both v1_0_0 and v1_3_0.
    function sendRequest(
        uint64,          // subscriptionId
        bytes calldata,  // data
        uint16,          // dataVersion
        uint32,          // callbackGasLimit
        bytes32          // donId
    ) external pure returns (bytes32) {
        return MOCK_REQUEST_ID;
    }
}
