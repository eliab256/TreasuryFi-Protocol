// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract MockReservesFunctionsConsumer {
    uint256 public sendRequestCallCount;

    function sendRequest() external {
        sendRequestCallCount++;
    }
}
