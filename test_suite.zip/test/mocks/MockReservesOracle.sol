// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

/**
 * @title MockReservesOracle
 * @notice Minimal IReservesOracle mock for ReservesFunctionsConsumer tests.
 *         Tracks how many times updateUsdValues has been called.
 */
contract MockReservesOracle {
    uint256 public updateCallCount;

    function updateUsdValues(
        uint256[4] memory, // bond
        uint256[4] memory, // cash
        uint256,           // timestamp
        bytes memory,      // signature
        bytes memory       // err
    ) external {
        updateCallCount++;
    }
}
