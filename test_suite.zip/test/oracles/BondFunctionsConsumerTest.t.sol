// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {BaseTest} from "../BaseTest.t.sol";
import {BondFunctionsConsumer} from "../../src/oracles/BondFunctionsConsumer.sol";
import {MockFunctionsRouter} from "../mocks/MockFunctionsRouter.sol";
import {MockBondOracle} from "../mocks/MockBondOracle.sol";

/**
 * @title BondFunctionsConsumerTest
 * @notice Unit tests for BondFunctionsConsumer — 100 % line and branch coverage.
 *
 * Coverage targets
 * ─────────────────────────────────────────────────────────────────────────────
 * constructor          : happy path (state + roles)
 * setSubscriptionId    : happy, zero-id revert, already-set revert, non-admin revert
 * sendRequest          : happy (returns correct id), non-updater revert
 * _fulfillRequest      : wrong requestId, err path (stores + emits timestamp=0),
 *                        valid response (4 values, calls oracle, emits),
 *                        invalid length (3 values, reverts),
 *                        oracle reverts (try-catch branch, still emits)
 * getters              : all five view functions
 *
 * Fulfillment strategy
 * ─────────────────────────────────────────────────────────────────────────────
 * _fulfillRequest is internal and gated behind FunctionsClient.handleOracleFulfillment
 * which requires msg.sender == i_router. Tests call handleOracleFulfillment
 * using vm.prank(address(mockRouter)) to satisfy this guard.
 */
contract BondFunctionsConsumerTest is BaseTest {
    // ─── Contract under test ──────────────────────────────────────────────────
    BondFunctionsConsumer internal consumer;

    // ─── Dependencies ─────────────────────────────────────────────────────────
    MockFunctionsRouter internal mockRouter;
    MockBondOracle      internal mockOracle;

    // ─── Constructor params ───────────────────────────────────────────────────
    bytes32 internal constant DON_ID     = keccak256("donId");
    uint32  internal constant GAS_LIMIT  = 300_000;
    uint64  internal constant SUB_ID     = 7;

    // ─── Yield values used in responses ──────────────────────────────────────
    uint256 internal constant YIELD_2Y  = 45_000;
    uint256 internal constant YIELD_5Y  = 42_000;
    uint256 internal constant YIELD_10Y = 43_000;
    uint256 internal constant YIELD_30Y = 46_000;

    // ─── BondFunctionsConsumer custom errors ──────────────────────────────────
    error BondFunctionsConsumer__InvalidSubscriptionId();
    error BondFunctionsConsumer__SubscriptionIdAlreadySet();

    // ─── Events ───────────────────────────────────────────────────────────────
    event SubscriptionIdSet(uint64 indexed subscriptionId);
    event Response(
        bytes32 indexed requestId,
        uint256         timestamp,
        bytes           response,
        bytes           err
    );

    // ─── Setup ────────────────────────────────────────────────────────────────

    function setUp() public override {
        super.setUp();

        mockRouter = new MockFunctionsRouter();
        mockOracle = new MockBondOracle();

        // ADMIN deploys → gets DEFAULT_ADMIN_ROLE and UPDATER_ROLE
        vm.prank(ADMIN);
        consumer = new BondFunctionsConsumer(
            address(mockRouter),
            DON_ID,
            GAS_LIMIT,
            address(mockOracle)
        );
    }

    // ─── Internal helpers ─────────────────────────────────────────────────────

    /// @dev Issues sendRequest as ADMIN (who holds UPDATER_ROLE) and returns
    ///      the stored request ID so fulfillment tests can use the correct ID.
    function _sendRequest() internal returns (bytes32 requestId) {
        vm.prank(ADMIN);
        requestId = consumer.sendRequest();
    }

    /// @dev Encodes a valid ABI response with four yield values and a timestamp.
    function _encodeValidResponse(uint256 ts)
        internal
        pure
        returns (bytes memory)
    {
        uint256[] memory values = new uint256[](4);
        values[0] = YIELD_2Y;
        values[1] = YIELD_5Y;
        values[2] = YIELD_10Y;
        values[3] = YIELD_30Y;
        return abi.encode(values, ts);
    }

    /// @dev Encodes an invalid ABI response with only three yield values.
    function _encodeInvalidLengthResponse() internal pure returns (bytes memory) {
        uint256[] memory values = new uint256[](3);
        values[0] = 1;
        values[1] = 2;
        values[2] = 3;
        return abi.encode(values, uint256(1));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Constructor
    // ═══════════════════════════════════════════════════════════════════════════

    function test_Constructor_SetsDonId() public view {
        assertEq(consumer.getDonID(), DON_ID);
    }

    function test_Constructor_SetsGasLimit() public view {
        assertEq(consumer.getGasLimit(), GAS_LIMIT);
    }

    function test_Constructor_SetsBondOracle() public view {
        assertEq(consumer.getBondOracle(), address(mockOracle));
    }

    function test_Constructor_SubscriptionIdInitialisedToZero() public view {
        assertEq(consumer.getSubscriptionId(), 0);
    }

    function test_Constructor_LastRequestIdInitialisedToZero() public view {
        assertEq(consumer.getLastRequestId(), bytes32(0));
    }

    function test_Constructor_DeployerReceivesDefaultAdminRole() public view {
        assertTrue(consumer.hasRole(DEFAULT_ADMIN_ROLE, ADMIN));
    }

    function test_Constructor_DeployerReceivesUpdaterRole() public view {
        assertTrue(consumer.hasRole(UPDATER_ROLE, ADMIN));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // setSubscriptionId
    // ═══════════════════════════════════════════════════════════════════════════

    function test_SetSubscriptionId_StoresId() public {
        vm.prank(ADMIN);
        consumer.setSubscriptionId(SUB_ID);

        assertEq(consumer.getSubscriptionId(), SUB_ID);
    }

    function test_SetSubscriptionId_EmitsEvent() public {
        vm.expectEmit(true, false, false, false);
        emit SubscriptionIdSet(SUB_ID);

        vm.prank(ADMIN);
        consumer.setSubscriptionId(SUB_ID);
    }

    function test_SetSubscriptionId_RevertsWhenIdIsZero() public {
        vm.prank(ADMIN);
        vm.expectRevert(BondFunctionsConsumer__InvalidSubscriptionId.selector);
        consumer.setSubscriptionId(0);
    }

    function test_SetSubscriptionId_RevertsWhenAlreadySet() public {
        vm.startPrank(ADMIN);
        consumer.setSubscriptionId(SUB_ID);

        vm.expectRevert(BondFunctionsConsumer__SubscriptionIdAlreadySet.selector);
        consumer.setSubscriptionId(SUB_ID);
        vm.stopPrank();
    }

    function test_SetSubscriptionId_RevertsWhenCallerLacksAdminRole() public {
        vm.prank(NON_ADMIN);
        vm.expectRevert(_unauthorizedRevert(NON_ADMIN, DEFAULT_ADMIN_ROLE));
        consumer.setSubscriptionId(SUB_ID);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // sendRequest
    // ═══════════════════════════════════════════════════════════════════════════

    function test_SendRequest_ReturnsRequestIdFromRouter() public {
        vm.prank(ADMIN);
        bytes32 returned = consumer.sendRequest();

        assertEq(returned, MockFunctionsRouter.MOCK_REQUEST_ID);
    }

    function test_SendRequest_StoresLastRequestId() public {
        _sendRequest();

        assertEq(consumer.getLastRequestId(), MockFunctionsRouter.MOCK_REQUEST_ID);
    }

    function test_SendRequest_RevertsWhenCallerLacksUpdaterRole() public {
        vm.prank(NON_ADMIN);
        vm.expectRevert(_unauthorizedRevert(NON_ADMIN, UPDATER_ROLE));
        consumer.sendRequest();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // _fulfillRequest — wrong request ID
    // ═══════════════════════════════════════════════════════════════════════════

    function test_FulfillRequest_RevertsWhenRequestIdMismatch() public {
        // s_lastRequestId is bytes32(0); any non-zero ID will mismatch
        bytes32 wrongId = keccak256("wrongId");

        vm.prank(address(mockRouter));
        vm.expectRevert(bytes("bad request id"));
        consumer.handleOracleFulfillment(wrongId, "", "");
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // _fulfillRequest — error branch (err.length > 0)
    // ═══════════════════════════════════════════════════════════════════════════

    function test_FulfillRequest_WithError_StoresErrorBytes() public {
        bytes32 requestId = _sendRequest();
        bytes memory errData = bytes("off-chain error");

        vm.prank(address(mockRouter));
        consumer.handleOracleFulfillment(requestId, bytes(""), errData);

        assertEq(consumer.getLastError(), errData);
    }

    function test_FulfillRequest_WithError_StoresResponseBytes() public {
        bytes32 requestId = _sendRequest();
        bytes memory respData = bytes("raw response");

        vm.prank(address(mockRouter));
        consumer.handleOracleFulfillment(requestId, respData, bytes("error"));

        assertEq(consumer.getLastResponse(), respData);
    }

    function test_FulfillRequest_WithError_EmitsResponseWithZeroTimestamp() public {
        bytes32 requestId = _sendRequest();
        bytes memory respData = bytes("raw response");
        bytes memory errData  = bytes("error");

        vm.expectEmit(true, false, false, true);
        emit Response(requestId, 0, respData, errData);

        vm.prank(address(mockRouter));
        consumer.handleOracleFulfillment(requestId, respData, errData);
    }

    function test_FulfillRequest_WithError_DoesNotCallOracle() public {
        bytes32 requestId = _sendRequest();

        vm.prank(address(mockRouter));
        consumer.handleOracleFulfillment(requestId, bytes(""), bytes("error"));

        assertEq(mockOracle.updateCallCount(), 0);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // _fulfillRequest — happy path (err.length == 0, valid 4-element response)
    // ═══════════════════════════════════════════════════════════════════════════

    function test_FulfillRequest_HappyPath_StoresResponse() public {
        bytes32 requestId    = _sendRequest();
        bytes memory response = _encodeValidResponse(block.timestamp);

        vm.prank(address(mockRouter));
        consumer.handleOracleFulfillment(requestId, response, bytes(""));

        assertEq(consumer.getLastResponse(), response);
    }

    function test_FulfillRequest_HappyPath_StoresEmptyError() public {
        bytes32 requestId = _sendRequest();

        vm.prank(address(mockRouter));
        consumer.handleOracleFulfillment(requestId, _encodeValidResponse(block.timestamp), bytes(""));

        assertEq(consumer.getLastError(), bytes(""));
    }

    function test_FulfillRequest_HappyPath_CallsOracle() public {
        bytes32 requestId = _sendRequest();

        vm.prank(address(mockRouter));
        consumer.handleOracleFulfillment(requestId, _encodeValidResponse(block.timestamp), bytes(""));

        assertEq(mockOracle.updateCallCount(), 1);
    }

    function test_FulfillRequest_HappyPath_EmitsResponseWithCorrectTimestamp() public {
        bytes32 requestId    = _sendRequest();
        uint256 ts           = block.timestamp;
        bytes memory response = _encodeValidResponse(ts);

        vm.expectEmit(true, false, false, true);
        emit Response(requestId, ts, response, bytes(""));

        vm.prank(address(mockRouter));
        consumer.handleOracleFulfillment(requestId, response, bytes(""));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // _fulfillRequest — invalid response length (values.length != 4)
    // ═══════════════════════════════════════════════════════════════════════════

    function test_FulfillRequest_RevertsWhenResponseHasFewerThanFourValues() public {
        bytes32 requestId = _sendRequest();

        vm.prank(address(mockRouter));
        vm.expectRevert(bytes("invalid length"));
        consumer.handleOracleFulfillment(requestId, _encodeInvalidLengthResponse(), bytes(""));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // _fulfillRequest — oracle reverts (try / catch branch)
    // ═══════════════════════════════════════════════════════════════════════════

    function test_FulfillRequest_OracleReverts_DoesNotPropagateRevert() public {
        mockOracle.setShouldRevert(true);
        bytes32 requestId = _sendRequest();

        // Must NOT revert even though the inner oracle call does
        vm.prank(address(mockRouter));
        consumer.handleOracleFulfillment(requestId, _encodeValidResponse(block.timestamp), bytes(""));
    }

    function test_FulfillRequest_OracleReverts_StillEmitsResponseEvent() public {
        mockOracle.setShouldRevert(true);
        bytes32 requestId    = _sendRequest();
        uint256 ts           = block.timestamp;
        bytes memory response = _encodeValidResponse(ts);

        vm.expectEmit(true, false, false, true);
        emit Response(requestId, ts, response, bytes(""));

        vm.prank(address(mockRouter));
        consumer.handleOracleFulfillment(requestId, response, bytes(""));
    }

    function test_FulfillRequest_OracleReverts_StoresResponse() public {
        mockOracle.setShouldRevert(true);
        bytes32 requestId    = _sendRequest();
        bytes memory response = _encodeValidResponse(block.timestamp);

        vm.prank(address(mockRouter));
        consumer.handleOracleFulfillment(requestId, response, bytes(""));

        assertEq(consumer.getLastResponse(), response);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Remaining getters (not covered elsewhere)
    // ═══════════════════════════════════════════════════════════════════════════

    function test_GetLastResponse_IsEmptyInitially() public view {
        assertEq(consumer.getLastResponse(), bytes(""));
    }

    function test_GetLastError_IsEmptyInitially() public view {
        assertEq(consumer.getLastError(), bytes(""));
    }
}
