// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {BaseTest} from "../BaseTest.t.sol";
import {BondOracle} from "../../src/oracles/BondOracle.sol";
import {BondYieldsResponse} from "../../src/types.sol";
import {IBondOracle} from "../../src/interfaces/IBondOracle.sol";
import {IERC165} from "@openzeppelin/contracts/utils/introspection/IERC165.sol";
import {IAccessControl} from "@openzeppelin/contracts/access/IAccessControl.sol";

/**
 * @title BondOracleTest
 * @notice Unit tests for BondOracle — 100 % line and branch coverage.
 *
 * Coverage targets
 * ─────────────────────────────────────────────────────────────────────────────
 * constructor       : happy path (roles + consumer address), zero-address revert
 * updateYields      : non-updater revert, error branch (early return + event),
 *                     incomplete-values revert, happy path (state + event)
 * getYield          : stale revert, slots 1–4, invalid slot revert,
 *                     stale again after threshold
 * getAllYields       : stale revert, full struct check, stale after threshold
 * isStale           : true initially, false after update, true after threshold
 * getLastUpdatedTimestamp : zero initially, set after update
 * getFunctionsConsumer    : returns stored address
 * supportsInterface : IBondOracle ✓, IERC165 ✓, unknown → false
 *
 * Staleness strategy
 * ─────────────────────────────────────────────────────────────────────────────
 * setUp calls _warpToStart() → block.timestamp = 200 days.
 * Uninitialized data has timestamp = 0 → 200 days − 0 > 48 hours → stale ✓.
 * After updateYields(ts = block.timestamp) → 0 > 48 hours → not stale ✓.
 */
contract BondOracleTest is BaseTest {
    // ─── Contract under test ──────────────────────────────────────────────────
    BondOracle internal bondOracle;

    // ─── Accounts ─────────────────────────────────────────────────────────────
    address internal UPDATER; // deployed as _functionsConsumer → gets UPDATER_ROLE

    // ─── Yield constants ──────────────────────────────────────────────────────
    uint256 internal constant YIELD_2Y  = 45_000; // 4.50 % in bps × 100
    uint256 internal constant YIELD_5Y  = 42_000;
    uint256 internal constant YIELD_10Y = 43_000;
    uint256 internal constant YIELD_30Y = 46_000;

    // ─── BondOracle custom errors ─────────────────────────────────────────────
    error BondOracle__ZeroAddress();
    error BondOracle__IncompleteResponse(uint256 received);
    error BondOracle__DataIsStale();
    error BondOracle__InvalidSlot();

    // ─── Events ───────────────────────────────────────────────────────────────
    event YieldUpdated(
        uint256 twoYearYield,
        uint256 fiveYearYield,
        uint256 tenYearYield,
        uint256 thirtyYearYield,
        uint256 timestamp
    );
    event YieldUpdateFailed(bytes err);

    // ─── Setup ────────────────────────────────────────────────────────────────

    function setUp() public override {
        super.setUp();
        _warpToStart(); // ensure timestamp=0 is treated as stale

        UPDATER = makeAddr("updater");

        // ADMIN deploys → DEFAULT_ADMIN_ROLE; UPDATER passed as functionsConsumer → UPDATER_ROLE
        vm.prank(ADMIN);
        bondOracle = new BondOracle(UPDATER);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    function _makeValues() internal pure returns (uint256[] memory values) {
        values = new uint256[](4);
        values[0] = YIELD_2Y;
        values[1] = YIELD_5Y;
        values[2] = YIELD_10Y;
        values[3] = YIELD_30Y;
    }

    /// @dev Performs a successful updateYields call at current block.timestamp.
    function _updateYields() internal {
        vm.prank(UPDATER);
        bondOracle.updateYields(_makeValues(), block.timestamp, bytes(""));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Constructor
    // ═══════════════════════════════════════════════════════════════════════════

    function test_Constructor_SetsFunctionsConsumerAddress() public view {
        assertEq(bondOracle.getFunctionsConsumer(), UPDATER);
    }

    function test_Constructor_GrantsDefaultAdminRoleToDeployer() public view {
        assertTrue(bondOracle.hasRole(DEFAULT_ADMIN_ROLE, ADMIN));
    }

    function test_Constructor_GrantsUpdaterRoleToFunctionsConsumer() public view {
        assertTrue(bondOracle.hasRole(UPDATER_ROLE, UPDATER));
    }

    function test_Constructor_RevertsWhenFunctionsConsumerIsZeroAddress() public {
        vm.expectRevert(BondOracle__ZeroAddress.selector);
        new BondOracle(address(0));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // updateYields — access control
    // ═══════════════════════════════════════════════════════════════════════════

    function test_UpdateYields_RevertsWhenCallerLacksUpdaterRole() public {
        vm.prank(NON_ADMIN);
        vm.expectRevert(_unauthorizedRevert(NON_ADMIN, UPDATER_ROLE));
        bondOracle.updateYields(_makeValues(), block.timestamp, bytes(""));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // updateYields — error branch (err.length > 0)
    // ═══════════════════════════════════════════════════════════════════════════

    function test_UpdateYields_WithError_EmitsYieldUpdateFailed() public {
        bytes memory errData = bytes("oracle error");

        vm.expectEmit(false, false, false, true);
        emit YieldUpdateFailed(errData);

        vm.prank(UPDATER);
        bondOracle.updateYields(_makeValues(), block.timestamp, errData);
    }

    function test_UpdateYields_WithError_DoesNotUpdateTimestamp() public {
        vm.prank(UPDATER);
        bondOracle.updateYields(_makeValues(), block.timestamp, bytes("error"));

        assertEq(bondOracle.getLastUpdatedTimestamp(), 0);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // updateYields — incomplete values revert (_values.length < 4)
    // ═══════════════════════════════════════════════════════════════════════════

    function test_UpdateYields_RevertsWhenValuesArrayIsTooShort() public {
        uint256[] memory shortValues = new uint256[](3);
        shortValues[0] = 1;
        shortValues[1] = 2;
        shortValues[2] = 3;

        vm.prank(UPDATER);
        vm.expectRevert(
            abi.encodeWithSelector(BondOracle__IncompleteResponse.selector, uint256(3))
        );
        bondOracle.updateYields(shortValues, block.timestamp, bytes(""));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // updateYields — happy path
    // ═══════════════════════════════════════════════════════════════════════════

    function test_UpdateYields_UpdatesTimestamp() public {
        uint256 ts = block.timestamp;
        _updateYields();

        assertEq(bondOracle.getLastUpdatedTimestamp(), ts);
    }

    function test_UpdateYields_EmitsYieldUpdated() public {
        uint256 ts = block.timestamp;

        vm.expectEmit(false, false, false, true);
        emit YieldUpdated(YIELD_2Y, YIELD_5Y, YIELD_10Y, YIELD_30Y, ts);

        vm.prank(UPDATER);
        bondOracle.updateYields(_makeValues(), ts, bytes(""));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // getYield
    // ═══════════════════════════════════════════════════════════════════════════

    function test_GetYield_RevertsWhenDataIsStale() public {
        // No update → timestamp = 0 → stale at STARTING_TIMESTAMP
        vm.expectRevert(BondOracle__DataIsStale.selector);
        bondOracle.getYield(1);
    }

    function test_GetYield_Slot1_ReturnsTwoYearYield() public {
        _updateYields();
        assertEq(bondOracle.getYield(1), YIELD_2Y);
    }

    function test_GetYield_Slot2_ReturnsFiveYearYield() public {
        _updateYields();
        assertEq(bondOracle.getYield(2), YIELD_5Y);
    }

    function test_GetYield_Slot3_ReturnsTenYearYield() public {
        _updateYields();
        assertEq(bondOracle.getYield(3), YIELD_10Y);
    }

    function test_GetYield_Slot4_ReturnsThirtyYearYield() public {
        _updateYields();
        assertEq(bondOracle.getYield(4), YIELD_30Y);
    }

    function test_GetYield_RevertsOnInvalidSlotZero() public {
        _updateYields();
        vm.expectRevert(BondOracle__InvalidSlot.selector);
        bondOracle.getYield(0);
    }

    function test_GetYield_RevertsOnInvalidSlotFive() public {
        _updateYields();
        vm.expectRevert(BondOracle__InvalidSlot.selector);
        bondOracle.getYield(5);
    }

    function test_GetYield_RevertsAfterDataBecomesStale() public {
        _updateYields();
        _warpPastStaleness();

        vm.expectRevert(BondOracle__DataIsStale.selector);
        bondOracle.getYield(1);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // getAllYields
    // ═══════════════════════════════════════════════════════════════════════════

    function test_GetAllYields_RevertsWhenDataIsStale() public {
        vm.expectRevert(BondOracle__DataIsStale.selector);
        bondOracle.getAllYields();
    }

    function test_GetAllYields_ReturnsCorrectStruct() public {
        uint256 ts = block.timestamp;
        _updateYields();

        BondYieldsResponse memory result = bondOracle.getAllYields();

        assertEq(result.twoYearYield,    YIELD_2Y);
        assertEq(result.fiveYearYield,   YIELD_5Y);
        assertEq(result.tenYearYield,    YIELD_10Y);
        assertEq(result.thirtyYearYield, YIELD_30Y);
        assertEq(result.timestamp,       ts);
    }

    function test_GetAllYields_RevertsAfterDataBecomesStale() public {
        _updateYields();
        _warpPastStaleness();

        vm.expectRevert(BondOracle__DataIsStale.selector);
        bondOracle.getAllYields();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // isStale
    // ═══════════════════════════════════════════════════════════════════════════

    function test_IsStale_ReturnsTrueWhenNoDataSet() public view {
        // timestamp = 0, block.timestamp = STARTING_TIMESTAMP (200 days) → stale
        assertTrue(bondOracle.isStale());
    }

    function test_IsStale_ReturnsFalseRightAfterUpdate() public {
        _updateYields();
        assertFalse(bondOracle.isStale());
    }

    function test_IsStale_ReturnsTrueAfterStalenessThresholdExpires() public {
        _updateYields();
        _warpPastStaleness();
        assertTrue(bondOracle.isStale());
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // getLastUpdatedTimestamp
    // ═══════════════════════════════════════════════════════════════════════════

    function test_GetLastUpdatedTimestamp_IsZeroInitially() public view {
        assertEq(bondOracle.getLastUpdatedTimestamp(), 0);
    }

    function test_GetLastUpdatedTimestamp_ReflectsTimestampPassedToUpdate() public {
        uint256 ts = block.timestamp;
        _updateYields();
        assertEq(bondOracle.getLastUpdatedTimestamp(), ts);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // supportsInterface
    // ═══════════════════════════════════════════════════════════════════════════

    function test_SupportsInterface_IBondOracle() public view {
        assertTrue(bondOracle.supportsInterface(type(IBondOracle).interfaceId));
    }

    function test_SupportsInterface_IERC165() public view {
        assertTrue(bondOracle.supportsInterface(type(IERC165).interfaceId));
    }

    function test_SupportsInterface_ReturnsFalseForUnknownInterface() public view {
        assertFalse(bondOracle.supportsInterface(bytes4(0xdeadbeef)));
    }
}
