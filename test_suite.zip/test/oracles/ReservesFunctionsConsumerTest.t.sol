// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {BaseTest} from "../BaseTest.t.sol";
import {ReservesFunctionsConsumer} from "../../src/oracles/ReservesFunctionsConsumer.sol";
import {MockFunctionsRouter} from "../mocks/MockFunctionsRouter.sol";
import {MockReservesOracle} from "../mocks/MockReservesOracle.sol";

/**
 * @title ReservesFunctionsConsumerTest
 * @notice Unit tests for ReservesFunctionsConsumer — 100 % line and branch coverage.
 *
 * Coverage targets
 * ─────────────────────────────────────────────────────────────────────────────
 * constructor       : happy path (state + roles)
 * setSubscriptionId : happy path (overwrites freely, no zero-check, no set-once),
 *                     non-admin revert
 * sendRequest       : happy (stores requestId), non-updater revert
 * _fulfillRequest   : wrong requestId revert, err branch (early return, no oracle
 *                     call), happy path (decodes response, calls oracle)
 * getters           : getLastRequestId, getSubscriptionId, getGasLimit,
 *                     getDonID, getOracle
 *
 * Key differences vs BondFunctionsConsumer
 * ─────────────────────────────────────────────────────────────────────────────
 * • setSubscriptionId has NO zero-id check and NO set-once guard — it can be
 *   called multiple times with any value including 0.
 * • _fulfillRequest does NOT store response/error and does NOT emit any event.
 *   When err.length > 0 it simply returns.
 *
 * Fulfillment strategy
 * ─────────────────────────────────────────────────────────────────────────────
 * _fulfillRequest is internal, reachable only through
 * FunctionsClient.handleOracleFulfillment which gates on msg.sender == i_router.
 * Tests call handleOracleFulfillment with vm.prank(address(mockRouter)).
 */
contract ReservesFunctionsConsumerTest is BaseTest {
    // ─── Contract under test ──────────────────────────────────────────────────
    ReservesFunctionsConsumer internal consumer;

    // ─── Dependencies ─────────────────────────────────────────────────────────
    MockFunctionsRouter internal mockRouter;
    MockReservesOracle  internal mockOracle;

    // ─── Constructor params ───────────────────────────────────────────────────
    bytes32 internal constant DON_ID    = keccak256("donId");
    uint32  internal constant GAS_LIMIT = 300_000;
    uint64  internal constant SUB_ID    = 9;
    uint64  internal constant SUB_ID_2  = 99; // used to verify overwrite

    // ─── Response payload constants ───────────────────────────────────────────
    uint256 internal constant BOND_0 = 100e8;
    uint256 internal constant BOND_1 = 200e8;
    uint256 internal constant BOND_2 = 300e8;
    uint256 internal constant BOND_3 = 400e8;

    uint256 internal constant CASH_0 = 10e8;
    uint256 internal constant CASH_1 = 20e8;
    uint256 internal constant CASH_2 = 30e8;
    uint256 internal constant CASH_3 = 40e8;

    uint256 internal constant RESPONSE_TIMESTAMP = 1_000_000;

    // ─── Setup ────────────────────────────────────────────────────────────────

    function setUp() public override {
        super.setUp();

        mockRouter = new MockFunctionsRouter();
        mockOracle = new MockReservesOracle();

        // ADMIN deploys → gets DEFAULT_ADMIN_ROLE and UPDATER_ROLE
        vm.prank(ADMIN);
        consumer = new ReservesFunctionsConsumer(
            address(mockRouter),
            DON_ID,
            GAS_LIMIT,
            address(mockOracle)
        );
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    /// @dev Sends a request as ADMIN and returns the stored requestId.
    function _sendRequest() internal returns (bytes32 requestId) {
        vm.prank(ADMIN);
        requestId = consumer.sendRequest();
    }

    /// @dev Builds bond and cash fixed arrays.
    function _makeBond() internal pure returns (uint256[4] memory) {
        return [BOND_0, BOND_1, BOND_2, BOND_3];
    }

    function _makeCash() internal pure returns (uint256[4] memory) {
        return [CASH_0, CASH_1, CASH_2, CASH_3];
    }

    /// @dev Encodes a well-formed response matching ReservesFunctionsConsumer's
    ///      abi.decode(response, (uint256[4], uint256[4], uint256, bytes)).
    function _encodeValidResponse() internal pure returns (bytes memory) {
        return abi.encode(
            _makeBond(),
            _makeCash(),
            RESPONSE_TIMESTAMP,
            bytes("mock-signature")
        );
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Constructor
    // ═══════════════════════════════════════════════════════════════════════════

    function test_Constructor_SetsDonId() public view {
        assertEq(consumer.getDonID(), DON_ID);
    }

    function test_Constructor_SetsGasLimit() public view {
        assertEq(consumer.getGasLimit(), GAS_LIMIT);
    }

    function test_Constructor_SetsOracle() public view {
        assertEq(consumer.getOracle(), address(mockOracle));
    }

    function test_Constructor_SubscriptionIdInitialisedToZero() public view {
        assertEq(consumer.getSubscriptionId(), 0);
    }

    function test_Constructor_LastRequestIdInitialisedToZero() public view {
        assertEq(consumer.getLastRequestId(), bytes32(0));
    }

    function test_Constructor_DeployerReceivesDefaultAdminRole() public view {
        assertTrue(consumer.hasRole(DEFAULT_ADMIN_ROLE, ADMIN));
    }

    function test_Constructor_DeployerReceivesUpdaterRole() public view {
        assertTrue(consumer.hasRole(UPDATER_ROLE, ADMIN));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // setSubscriptionId
    // ─────────────────────────────────────────────────────────────────────────
    // NOTE: unlike BondFunctionsConsumer, there is NO zero-id check and NO
    // set-once guard. The setter may be called repeatedly with any value.
    // ═══════════════════════════════════════════════════════════════════════════

    function test_SetSubscriptionId_StoresId() public {
        vm.prank(ADMIN);
        consumer.setSubscriptionId(SUB_ID);

        assertEq(consumer.getSubscriptionId(), SUB_ID);
    }

    function test_SetSubscriptionId_AcceptsZero() public {
        // No revert expected — there is no zero-id guard in this contract
        vm.prank(ADMIN);
        consumer.setSubscriptionId(0);

        assertEq(consumer.getSubscriptionId(), 0);
    }

    function test_SetSubscriptionId_CanBeCalledMultipleTimes() public {
        vm.startPrank(ADMIN);
        consumer.setSubscriptionId(SUB_ID);
        consumer.setSubscriptionId(SUB_ID_2); // second call must not revert
        vm.stopPrank();

        assertEq(consumer.getSubscriptionId(), SUB_ID_2);
    }

    function test_SetSubscriptionId_RevertsWhenCallerLacksAdminRole() public {
        vm.prank(NON_ADMIN);
        vm.expectRevert(_unauthorizedRevert(NON_ADMIN, DEFAULT_ADMIN_ROLE));
        consumer.setSubscriptionId(SUB_ID);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // sendRequest
    // ═══════════════════════════════════════════════════════════════════════════

    function test_SendRequest_ReturnsRequestIdFromRouter() public {
        vm.prank(ADMIN);
        bytes32 returned = consumer.sendRequest();

        assertEq(returned, MockFunctionsRouter.MOCK_REQUEST_ID);
    }

    function test_SendRequest_StoresLastRequestId() public {
        _sendRequest();

        assertEq(consumer.getLastRequestId(), MockFunctionsRouter.MOCK_REQUEST_ID);
    }

    function test_SendRequest_RevertsWhenCallerLacksUpdaterRole() public {
        vm.prank(NON_ADMIN);
        vm.expectRevert(_unauthorizedRevert(NON_ADMIN, UPDATER_ROLE));
        consumer.sendRequest();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // _fulfillRequest — wrong request ID
    // ═══════════════════════════════════════════════════════════════════════════

    function test_FulfillRequest_RevertsWhenRequestIdMismatch() public {
        // s_lastRequestId is bytes32(0); any non-zero id causes a mismatch
        bytes32 wrongId = keccak256("wrongId");

        vm.prank(address(mockRouter));
        vm.expectRevert(bytes("bad request"));
        consumer.handleOracleFulfillment(wrongId, bytes(""), bytes(""));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // _fulfillRequest — error branch (err.length > 0)
    // ═══════════════════════════════════════════════════════════════════════════

    function test_FulfillRequest_WithError_ReturnsEarlyWithoutCallingOracle() public {
        bytes32 requestId = _sendRequest();

        vm.prank(address(mockRouter));
        consumer.handleOracleFulfillment(requestId, bytes(""), bytes("off-chain error"));

        // Early return → oracle must NOT have been called
        assertEq(mockOracle.updateCallCount(), 0);
    }

    function test_FulfillRequest_WithError_DoesNotRevert() public {
        bytes32 requestId = _sendRequest();

        // Must complete without reverting
        vm.prank(address(mockRouter));
        consumer.handleOracleFulfillment(requestId, bytes(""), bytes("error"));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // _fulfillRequest — happy path (err.length == 0, valid response)
    // ═══════════════════════════════════════════════════════════════════════════

    function test_FulfillRequest_HappyPath_CallsOracle() public {
        bytes32 requestId = _sendRequest();

        vm.prank(address(mockRouter));
        consumer.handleOracleFulfillment(requestId, _encodeValidResponse(), bytes(""));

        assertEq(mockOracle.updateCallCount(), 1);
    }

    function test_FulfillRequest_HappyPath_CalledTwiceCallsOracleTwice() public {
        // Set up a second distinct request so both IDs match their own fulfillment
        bytes32 requestId = _sendRequest();

        vm.prank(address(mockRouter));
        consumer.handleOracleFulfillment(requestId, _encodeValidResponse(), bytes(""));

        // Second round (sendRequest overwrites s_lastRequestId with the same mock value)
        requestId = _sendRequest();

        vm.prank(address(mockRouter));
        consumer.handleOracleFulfillment(requestId, _encodeValidResponse(), bytes(""));

        assertEq(mockOracle.updateCallCount(), 2);
    }
}
