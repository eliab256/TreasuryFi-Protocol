// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {BaseTest} from "../BaseTest.t.sol";
import {ReservesOracle} from "../../src/oracles/ReservesOracle.sol";
import {ReservesResponse} from "../../src/types.sol";

/**
 * @title ReservesOracleTest
 * @notice Unit tests for ReservesOracle — 100 % line and branch coverage.
 *
 * Coverage targets
 * ─────────────────────────────────────────────────────────────────────────────
 * constructor            : happy path (roles + signer stored implicitly)
 * updateUsdValues        : non-updater revert, err branch (early return),
 *                          invalid-signature revert, happy path (state + event)
 * getAllReserves          : stale revert, full struct verification
 * getTotalUsdValue        : stale revert, correct sum (bondSum + cashSum)
 * isStale / _isStale     : true initially, false after update, true again
 * getLastUpdatedTimestamp : zero initially, set after update
 *
 * ECDSA signing strategy
 * ─────────────────────────────────────────────────────────────────────────────
 * The contract uses raw ECDSA.recover(hash, signature) without any Ethereum
 * message prefix.  Foundry's vm.sign(privateKey, digest) also signs raw hashes,
 * so signatures produced with vm.sign match what the contract expects.
 *
 * Signature format expected by OZ ECDSA: 65 bytes = r (32) ++ s (32) ++ v (1).
 * vm.sign returns (v, r, s) — we re-pack as abi.encodePacked(r, s, v).
 *
 * totalUsdBondsValue note
 * ─────────────────────────────────────────────────────────────────────────────
 * Despite its name, the field is computed as bondSum + cashSum (see contract).
 * Tests verify the actual on-chain behaviour, not the name.
 *
 * Staleness strategy
 * ─────────────────────────────────────────────────────────────────────────────
 * setUp calls _warpToStart() → block.timestamp = 200 days.
 * Uninitialized state has timestamp = 0 → 200 days − 0 > 48 hours → stale ✓.
 */
contract ReservesOracleTest is BaseTest {
    // ─── Contract under test ──────────────────────────────────────────────────
    ReservesOracle internal reservesOracle;

    // ─── Signing key pair ─────────────────────────────────────────────────────
    uint256 internal constant SIGNER_PRIVATE_KEY = 0xA11CE;
    address internal SIGNER; // derived from SIGNER_PRIVATE_KEY in setUp

    // ─── Accounts ─────────────────────────────────────────────────────────────
    address internal UPDATER; // passed as `consumer` → gets UPDATER_ROLE

    // ─── Reserve values ───────────────────────────────────────────────────────
    uint256 internal constant BOND_0 = 100e8;
    uint256 internal constant BOND_1 = 200e8;
    uint256 internal constant BOND_2 = 300e8;
    uint256 internal constant BOND_3 = 400e8;

    uint256 internal constant CASH_0 = 10e8;
    uint256 internal constant CASH_1 = 20e8;
    uint256 internal constant CASH_2 = 30e8;
    uint256 internal constant CASH_3 = 40e8;

    // Precomputed sums (verified against the contract formula)
    uint256 internal constant BOND_SUM =
        BOND_0 + BOND_1 + BOND_2 + BOND_3; // 1000e8
    uint256 internal constant CASH_SUM =
        CASH_0 + CASH_1 + CASH_2 + CASH_3; // 100e8
    /// @dev totalUsdBondsValue = bondSum + cashSum (per contract implementation)
    uint256 internal constant EXPECTED_TOTAL = BOND_SUM + CASH_SUM; // 1100e8

    // ─── ReservesOracle custom errors ─────────────────────────────────────────
    error ReservesOracle__InvalidSignature(address recovered);

    // ─── Events ───────────────────────────────────────────────────────────────
    event UsdValueUpdated(
        uint256 twoYearUsdBondsValue,
        uint256 fiveYearUsdBondsValue,
        uint256 tenYearUsdBondsValue,
        uint256 thirtyYearUsdBondsValue,
        uint256 totalUsdValue,
        uint256 timestamp
    );

    // ─── Setup ────────────────────────────────────────────────────────────────

    function setUp() public override {
        super.setUp();
        _warpToStart(); // ensure timestamp = 0 reads as stale

        SIGNER  = vm.addr(SIGNER_PRIVATE_KEY);
        UPDATER = makeAddr("updater");

        // ADMIN deploys → DEFAULT_ADMIN_ROLE; UPDATER is `consumer` → UPDATER_ROLE
        vm.prank(ADMIN);
        reservesOracle = new ReservesOracle(UPDATER, SIGNER);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    function _makeBond() internal pure returns (uint256[4] memory) {
        return [BOND_0, BOND_1, BOND_2, BOND_3];
    }

    function _makeCash() internal pure returns (uint256[4] memory) {
        return [CASH_0, CASH_1, CASH_2, CASH_3];
    }

    /// @dev Produces a valid ECDSA signature over (bond, cash, timestamp)
    ///      that matches what the contract reconstructs in updateUsdValues.
    function _makeValidSignature(
        uint256[4] memory bond,
        uint256[4] memory cash,
        uint256 ts
    ) internal returns (bytes memory) {
        bytes32 hash = keccak256(abi.encode(bond, cash, ts));
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(SIGNER_PRIVATE_KEY, hash);
        // OZ ECDSA expects 65-byte signature: r ++ s ++ v
        return abi.encodePacked(r, s, v);
    }

    /// @dev Calls updateUsdValues successfully with current block.timestamp
    ///      and returns the timestamp used.
    function _updateValues() internal returns (uint256 ts) {
        ts = block.timestamp;
        uint256[4] memory bond = _makeBond();
        uint256[4] memory cash = _makeCash();
        bytes memory sig = _makeValidSignature(bond, cash, ts);

        vm.prank(UPDATER);
        reservesOracle.updateUsdValues(bond, cash, ts, sig, bytes(""));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Constructor
    // ═══════════════════════════════════════════════════════════════════════════

    function test_Constructor_GrantsDefaultAdminRoleToDeployer() public view {
        assertTrue(reservesOracle.hasRole(DEFAULT_ADMIN_ROLE, ADMIN));
    }

    function test_Constructor_GrantsUpdaterRoleToConsumer() public view {
        assertTrue(reservesOracle.hasRole(UPDATER_ROLE, UPDATER));
    }

    function test_Constructor_LastUpdatedTimestampIsZero() public view {
        assertEq(reservesOracle.getLastUpdatedTimestamp(), 0);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // updateUsdValues — access control
    // ═══════════════════════════════════════════════════════════════════════════

    function test_UpdateUsdValues_RevertsWhenCallerLacksUpdaterRole() public {
        uint256[4] memory bond = _makeBond();
        uint256[4] memory cash = _makeCash();
        uint256 ts = block.timestamp;
        bytes memory sig = _makeValidSignature(bond, cash, ts);

        vm.prank(NON_ADMIN);
        vm.expectRevert(_unauthorizedRevert(NON_ADMIN, UPDATER_ROLE));
        reservesOracle.updateUsdValues(bond, cash, ts, sig, bytes(""));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // updateUsdValues — error branch (err.length > 0)
    // ═══════════════════════════════════════════════════════════════════════════

    function test_UpdateUsdValues_WithError_ReturnsEarlyWithoutUpdatingState() public {
        uint256[4] memory bond = _makeBond();
        uint256[4] memory cash = _makeCash();

        vm.prank(UPDATER);
        reservesOracle.updateUsdValues(bond, cash, block.timestamp, bytes("sig"), bytes("error"));

        // State must remain unset (timestamp stays at 0)
        assertEq(reservesOracle.getLastUpdatedTimestamp(), 0);
    }

    function test_UpdateUsdValues_WithError_DoesNotRevert() public {
        vm.prank(UPDATER);
        // Must complete without reverting regardless of signature content
        reservesOracle.updateUsdValues(
            _makeBond(), _makeCash(), block.timestamp, bytes("bad-sig"), bytes("err")
        );
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // updateUsdValues — invalid signature
    // ═══════════════════════════════════════════════════════════════════════════

    function test_UpdateUsdValues_RevertsWhenSignatureIsInvalid() public {
        uint256[4] memory bond = _makeBond();
        uint256[4] memory cash = _makeCash();
        uint256 ts = block.timestamp;

        // Sign with a completely different private key
        uint256 wrongKey  = 0xBAD;
        bytes32 hash      = keccak256(abi.encode(bond, cash, ts));
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(wrongKey, hash);
        bytes memory wrongSig = abi.encodePacked(r, s, v);
        address wrongSigner   = vm.addr(wrongKey);

        vm.prank(UPDATER);
        vm.expectRevert(
            abi.encodeWithSelector(ReservesOracle__InvalidSignature.selector, wrongSigner)
        );
        reservesOracle.updateUsdValues(bond, cash, ts, wrongSig, bytes(""));
    }

    function test_UpdateUsdValues_RevertsWhenSignatureCoversWrongData() public {
        uint256[4] memory bond = _makeBond();
        uint256[4] memory cash = _makeCash();
        uint256 ts             = block.timestamp;

        // Sign a different timestamp → hash mismatch → recovered != SIGNER
        bytes memory sig = _makeValidSignature(bond, cash, ts + 1);

        vm.prank(UPDATER);
        vm.expectRevert(); // InvalidSignature with wrong recovered address
        reservesOracle.updateUsdValues(bond, cash, ts, sig, bytes(""));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // updateUsdValues — happy path
    // ═══════════════════════════════════════════════════════════════════════════

    function test_UpdateUsdValues_HappyPath_UpdatesTimestamp() public {
        uint256 ts = _updateValues();
        assertEq(reservesOracle.getLastUpdatedTimestamp(), ts);
    }

    function test_UpdateUsdValues_HappyPath_EmitsUsdValueUpdated() public {
        uint256 ts   = block.timestamp;
        uint256[4] memory bond = _makeBond();
        uint256[4] memory cash = _makeCash();
        bytes memory sig = _makeValidSignature(bond, cash, ts);

        vm.expectEmit(false, false, false, true);
        emit UsdValueUpdated(BOND_0, BOND_1, BOND_2, BOND_3, EXPECTED_TOTAL, ts);

        vm.prank(UPDATER);
        reservesOracle.updateUsdValues(bond, cash, ts, sig, bytes(""));
    }

    function test_UpdateUsdValues_HappyPath_StoresBondBuckets() public {
        _updateValues();

        ReservesResponse memory state = reservesOracle.getAllReserves();
        assertEq(state.twoYearUsdBondsValue,    BOND_0);
        assertEq(state.fiveYearUsdBondsValue,   BOND_1);
        assertEq(state.tenYearUsdBondsValue,    BOND_2);
        assertEq(state.thirtyYearUsdBondsValue, BOND_3);
    }

    function test_UpdateUsdValues_HappyPath_StoresCashBuckets() public {
        _updateValues();

        ReservesResponse memory state = reservesOracle.getAllReserves();
        assertEq(state.twoYearUsdCashValue,    CASH_0);
        assertEq(state.fiveYearUsdCashValue,   CASH_1);
        assertEq(state.tenYearUsdCashValue,    CASH_2);
        assertEq(state.thirtyYearUsdCashValue, CASH_3);
    }

    function test_UpdateUsdValues_HappyPath_StoresCashBufferTotal() public {
        _updateValues();

        ReservesResponse memory state = reservesOracle.getAllReserves();
        assertEq(state.cashBufferUsdTotalValue, CASH_SUM);
    }

    function test_UpdateUsdValues_HappyPath_StoresTotalUsdValueAsBondPlusCash() public {
        // totalUsdBondsValue = bondSum + cashSum (per contract — see audit note)
        _updateValues();

        ReservesResponse memory state = reservesOracle.getAllReserves();
        assertEq(state.totalUsdBondsValue, EXPECTED_TOTAL);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // getAllReserves
    // ═══════════════════════════════════════════════════════════════════════════

    function test_GetAllReserves_RevertsWhenDataIsStale() public {
        // No update → timestamp = 0 → stale at STARTING_TIMESTAMP
        vm.expectRevert(bytes("stale data"));
        reservesOracle.getAllReserves();
    }

    function test_GetAllReserves_ReturnsFullStructCorrectly() public {
        uint256 ts = _updateValues();

        ReservesResponse memory state = reservesOracle.getAllReserves();

        assertEq(state.twoYearUsdBondsValue,    BOND_0);
        assertEq(state.fiveYearUsdBondsValue,   BOND_1);
        assertEq(state.tenYearUsdBondsValue,    BOND_2);
        assertEq(state.thirtyYearUsdBondsValue, BOND_3);
        assertEq(state.twoYearUsdCashValue,     CASH_0);
        assertEq(state.fiveYearUsdCashValue,    CASH_1);
        assertEq(state.tenYearUsdCashValue,     CASH_2);
        assertEq(state.thirtyYearUsdCashValue,  CASH_3);
        assertEq(state.cashBufferUsdTotalValue, CASH_SUM);
        assertEq(state.totalUsdBondsValue,      EXPECTED_TOTAL);
        assertEq(state.timestamp,               ts);
    }

    function test_GetAllReserves_RevertsAfterDataBecomesStale() public {
        _updateValues();
        _warpPastStaleness();

        vm.expectRevert(bytes("stale data"));
        reservesOracle.getAllReserves();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // getTotalUsdValue
    // ═══════════════════════════════════════════════════════════════════════════

    function test_GetTotalUsdValue_RevertsWhenDataIsStale() public {
        vm.expectRevert(bytes("stale data"));
        reservesOracle.getTotalUsdValue();
    }

    function test_GetTotalUsdValue_ReturnsBondSumPlusCashSum() public {
        _updateValues();
        assertEq(reservesOracle.getTotalUsdValue(), EXPECTED_TOTAL);
    }

    function test_GetTotalUsdValue_RevertsAfterDataBecomesStale() public {
        _updateValues();
        _warpPastStaleness();

        vm.expectRevert(bytes("stale data"));
        reservesOracle.getTotalUsdValue();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // isStale / _isStale
    // ═══════════════════════════════════════════════════════════════════════════

    function test_IsStale_ReturnsTrueWhenNoDataSet() public view {
        // timestamp = 0, block.timestamp = STARTING_TIMESTAMP (200 days) → stale
        assertTrue(reservesOracle.isStale());
    }

    function test_IsStale_ReturnsFalseRightAfterUpdate() public {
        _updateValues();
        assertFalse(reservesOracle.isStale());
    }

    function test_IsStale_ReturnsTrueAfterStalenessThresholdExpires() public {
        _updateValues();
        _warpPastStaleness();
        assertTrue(reservesOracle.isStale());
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // getLastUpdatedTimestamp
    // ═══════════════════════════════════════════════════════════════════════════

    function test_GetLastUpdatedTimestamp_IsZeroInitially() public view {
        assertEq(reservesOracle.getLastUpdatedTimestamp(), 0);
    }

    function test_GetLastUpdatedTimestamp_ReflectsTimestampPassedToUpdate() public {
        uint256 ts = _updateValues();
        assertEq(reservesOracle.getLastUpdatedTimestamp(), ts);
    }
}
